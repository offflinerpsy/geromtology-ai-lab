import type {Metadata} from "next";
import Header from "@/components/site/header";
import Footer from "@/components/site/footer";
import Motion from "./motion";
import "./globals.css";
import "./premium.css";
export const metadata:Metadata={title:{default:"Open Institute of Age and Aging — Gerontology & AI Research",template:"%s | Open Institute of Age and Aging"},description:"Research, medical expertise and education for healthy aging. Explore the institute, research programs and ProAge Atlas AI laboratory.",icons:{icon:"/favicon.svg",shortcut:"/favicon.svg"}};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="en"><head><link rel="preload" href="/fonts/inter-regular.woff" as="font" type="font/woff" crossOrigin="anonymous"/><link rel="preload" href="/fonts/newsreader-regular.woff" as="font" type="font/woff" crossOrigin="anonymous"/></head><body><a className="skip-link" href="#main">Skip to content</a><Header/><Motion/>{children}<Footer/></body></html>}
